# age-calculator
This is a age calculator made with pure javascript, html, css. Using this little app you can calculate your age.

[Live Demo](https://emranweb.github.io/age-calculator/)
